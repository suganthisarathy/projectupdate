package com.example.stockspring.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.stockspring.model.Company;

public interface CompanyDao extends JpaRepository<Company, Integer> {
	 
List<Company> findBySectorId(int sectorId);

@Query("select c from Company c where c.companyName like %:name%")
List<Company> findNameWithPattern(@Param("name") String name);
@Query("select c.companyId from Company c where c.sectorId=:sectorid")
int[] findSectorList(@Param("sectorid")int sectorid);
}