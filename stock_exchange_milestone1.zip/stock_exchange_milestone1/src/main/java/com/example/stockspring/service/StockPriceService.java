package com.example.stockspring.service;

import java.util.List;

import com.example.stockspring.model.StockPriceDetails;

public interface StockPriceService {
	public List<StockPriceDetails> getStockPriceList() throws Exception ;
}
