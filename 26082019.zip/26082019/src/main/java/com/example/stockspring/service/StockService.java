package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;



import com.example.stockspring.model.StockExchange;

public interface StockService {
	public StockExchange insertStock(StockExchange stock) throws SQLException;
    public StockExchange updateStock(StockExchange stock);
	public List<StockExchange> getStockList() throws Exception;
	public StockExchange getStockId(int companyId);
	
}
