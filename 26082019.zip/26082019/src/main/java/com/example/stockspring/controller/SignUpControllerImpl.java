package com.example.stockspring.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.model.User;
import com.example.stockspring.service.SignUpService;

@Controller
public class SignUpControllerImpl implements SignUpController {
	@Autowired
	public SignUpService signUpService;

	@Override
	@RequestMapping(path = "/hello")
	public String hi() {
		return "index";
	}

	

	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public String getRegistrationForm(ModelMap model) {

		User u = new User();
		// e.setEmail("sdfsf");
		// e.setSalary(4564.56f);
		model.addAttribute("u1", u);
		return "Signup";
	}

	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public String insertUser(@ModelAttribute("u1") @Valid User user, BindingResult result, Model model)
			throws SQLException {
		if (result.hasErrors()) {
			System.out.println("errors");
			System.out.println(result.getAllErrors());

			return "Signup";
		}
		signUpService.insertUser(user);

		return "redirect:/logincheck";

	}

	@RequestMapping(value = "/logincheck", method = RequestMethod.GET)
	public String loginCheck(ModelMap model) {

		User u = new User();
		// e.setEmail("sdfsf");
		// e.setSalary(4564.56f);
		model.addAttribute("u2", u);
		return "AdminLogin";
	}
	/*@RequestMapping(value = "/logincheck", method = RequestMethod.POST)
	public String loginCheckUser(@ModelAttribute("u2") @Valid User user, BindingResult result, Model model) throws SQLException {

		User u = new User();
		
		// e.setEmail("sdfsf");
		// e.setSalary(4564.56f);
		if(user.getUserName().equals("admin"))
		{
			return "AdminLandingPage";
		}
		
		
		
		return "UserLandingPage";
		
	}*/


	/*@RequestMapping(value = "/logincheck", method = RequestMethod.POST)
	public ModelAndView loginCheckUser(@ModelAttribute("u2") @Valid User user, BindingResult result, Model model)
			throws SQLException {
		if (result.hasErrors()) {
			System.out.println("errors");
			System.out.println(result.getAllErrors());

			// return "AdminLogin";
		}
		User userdb = null;
		userdb = signUpService.getUserList(user);
		ModelAndView mv = null;
		System.out.println(userdb.getUserName());
		System.out.println(user.getUserName());
		if (userdb.getUserName()!=null) {
			mv = new ModelAndView("UserLandingPage");
		} else {

			mv = new ModelAndView("AdminLogin", "msg", "invalid username or password");
		}
		return mv;

	}*/
	@RequestMapping(path = "/logincheck", method = RequestMethod.POST)
    public ModelAndView loginCheck(@Valid @ModelAttribute("u2") User user) throws Exception {

           ModelAndView mav = null;

           String name = user.getUserName();
           List<User> user1 = signUpService.findByuserName(name);
          System.out.println(user1);
           User user2 = user1.get(0);

           if ((user.getUserName().equals(user2.getUserName())) && (user.getPassword().equals(user2.getPassword()))) {

                  if (user.getUserName().equals("admin")) {
                        mav = new ModelAndView("AdminLandingPage");
                  } else {
                        mav = new ModelAndView("UserLandingPage");
        }
           } else {

                  mav = new ModelAndView("AdminLogin", "message", "Invalid Username or Password");
           }

           return mav;

    }


}