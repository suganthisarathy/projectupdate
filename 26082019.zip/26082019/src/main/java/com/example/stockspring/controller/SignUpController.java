package com.example.stockspring.controller;

public interface SignUpController {
	public String hi();
	
	
}
