package com.example.stockspring.dao;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.stockspring.model.StockPriceDetails;

public interface StockPriceDao extends JpaRepository<StockPriceDetails, Integer>{
     
	@Query("select s.currentPrice from StockPriceDetails s where s.companycode=:companycode and s.date between :date1 and :date2")
	List<Double> findBycompanycode(@Param ("companycode") int companycode,@Param("date1") Date Date1,@Param("date2") Date date2);

}
