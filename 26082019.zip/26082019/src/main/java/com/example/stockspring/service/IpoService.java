package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import javax.validation.Valid;

import com.example.stockspring.model.Company;
import com.example.stockspring.model.IpoPlanned;

public interface IpoService {

	IpoPlanned insertIpo(IpoPlanned ipo) throws SQLException;

	IpoPlanned updateIpo( Company ipo);

	List<IpoPlanned> getIpoList() throws Exception;
     
	 IpoPlanned getIpoId(int ipoId) ;
		

 
}
