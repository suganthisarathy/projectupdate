package com.example.stockspring.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.stockspring.model.Sectors;
import com.example.stockspring.service.CompanyService;
import com.example.stockspring.service.SectorService;
@Controller
public class SectorControllerImpl implements SectorController {
	@Autowired
	private SectorService sectorService;
	@Override
	@RequestMapping(value = "/addSector", method = RequestMethod.GET)
	public String insertSector(Sectors sector) throws SQLException {
		// TODO Auto-generated method stub
		 sectorService.insertSector(sector);
		 return "UserLandingPage";
	}

	@Override
	public Sectors updateSector(Sectors sector) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@RequestMapping(value = "/listSector", method = RequestMethod.GET)
	public List<Sectors> geSectorList() throws Exception {
		// TODO Auto-generated method stub
		return sectorService.getSectorList();
	}

}
